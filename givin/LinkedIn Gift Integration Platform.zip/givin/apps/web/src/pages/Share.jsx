import { useMemo, useState } from "react";
import { useLocation, useNavigate, Navigate } from "react-router-dom";
import { Logo } from "../components/Logo";

// Shown after a sender creates a shareable gift link.
// Goal: make it trivially easy to drop the gift into a LinkedIn message or post.
export default function Share() {
  const { state } = useLocation();
  const nav = useNavigate();
  const [copied, setCopied] = useState(null); // 'link' | 'msg'

  if (!state?.link) return <Navigate to="/app" replace />;
  const { link, gift, message, name } = state;
  const first = (name || "").split(" ")[0];

  // The ready-to-paste LinkedIn message: their note + the gift link.
  const shareText = useMemo(() => {
    const note = (message || "").trim();
    return `${note}${note ? "\n\n" : ""}🎁 Your gift is here — pick what you'd like:\n${link}`;
  }, [message, link]);

  async function copy(what, text) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(what);
      setTimeout(() => setCopied(null), 1800);
    } catch {
      setCopied(null);
    }
  }

  const liShare = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(link)}`;
  const liMessages = "https://www.linkedin.com/messaging/";

  function nativeShare() {
    if (navigator.share) navigator.share({ text: shareText, url: link }).catch(() => {});
    else copy("msg", shareText);
  }

  return (
    <>
      <div className="topbar">
        <Logo />
        <div className="spacer" />
        <button className="btn ghost sm" onClick={() => nav("/app")}>Done</button>
      </div>

      <div className="wrap section" style={{ maxWidth: 460 }}>
        <div className="center">
          <div className="checkmark">🎁</div>
          <h1 className="h1" style={{ marginTop: 12 }}>Your gift link is ready</h1>
          <p className="sub">
            {gift ? <><strong>{gift}</strong> for {first || "your friend"}. </> : null}
            Paste it into a LinkedIn message or post — they pick what they’d like.
          </p>
        </div>

        {/* The link */}
        <div className="label">GIFT LINK</div>
        <div className="linkrow">
          <input className="input mono" readOnly value={link} onFocus={(e) => e.target.select()} style={{ fontSize: 12 }} />
          <button className="btn primary" onClick={() => copy("link", link)} style={{ flex: "none" }}>
            {copied === "link" ? "Copied ✓" : "Copy"}
          </button>
        </div>

        {/* Ready-to-paste message */}
        <div className="label">READY-TO-PASTE MESSAGE</div>
        <textarea className="textarea" readOnly value={shareText} style={{ minHeight: 110, fontSize: 13.5 }} onFocus={(e) => e.target.select()} />
        <button className="btn ghost block" style={{ marginTop: 8 }} onClick={() => copy("msg", shareText)}>
          {copied === "msg" ? "Copied ✓" : "Copy message"}
        </button>

        {/* Post / share actions */}
        <div className="label">POST IT ON LINKEDIN</div>
        <div className="share-actions">
          <a className="btn primary block" href={liShare} target="_blank" rel="noreferrer">Share as a post</a>
          <a className="btn ghost block" href={liMessages} target="_blank" rel="noreferrer">Open LinkedIn messages</a>
          <button className="btn ghost block" onClick={nativeShare}>Share…</button>
        </div>

        <div className="tipcard">
          <div className="mono tiny" style={{ color: "var(--faint)", letterSpacing: ".1em" }}>HOW IT WORKS</div>
          <p style={{ fontSize: 13, margin: "6px 0 0", lineHeight: 1.5 }}>
            Open your chat with {first || "your friend"} on LinkedIn, paste the message, and send. When they
            open the link they choose their gift and redeem it — no address, no account needed.
          </p>
        </div>

        <button className="btn ghost block" style={{ marginTop: 18 }} onClick={() => nav("/send")}>
          Send another gift
        </button>
      </div>
    </>
  );
}
