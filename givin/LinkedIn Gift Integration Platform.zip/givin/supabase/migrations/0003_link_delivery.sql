-- ─────────────────────────────────────────────────────────────
-- Givin · shareable gift links
-- A sender can create a gift LINK (no recipient email needed) and
-- paste it into a LinkedIn message or post. So email becomes optional
-- and we record how the gift was delivered.
-- ─────────────────────────────────────────────────────────────

alter table orders alter column recipient_email drop not null;
alter table orders alter column recipient_name set default 'A friend';
alter table orders add column if not exists delivery_mode text not null default 'email'; -- link | email
