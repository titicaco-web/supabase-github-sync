-- ─────────────────────────────────────────────────────────────
-- Givin · analytics — admin dashboard views + supporting columns
-- Powers "Givin Admin Dashboard". All figures derive from
-- orders / gifts / recipients / profiles. Admin-only access is
-- enforced in the app via has_role(auth.uid(),'admin').
-- ─────────────────────────────────────────────────────────────

-- Optional columns that enable the geography / segment / channel cuts.
alter table orders   add column if not exists recipient_country text; -- ISO-2, set at redeem
alter table orders   add column if not exists channel text;           -- utm source at first touch
alter table profiles add column if not exists persona text;           -- sales|recruiter|founder|consultant

-- gifts.revenue not stored per-order; we approximate paid revenue from value_cents.

-- ── A/B experiments (written by the app; empty until used) ──
create table if not exists experiments (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  metric      text,
  variant     text not null,          -- 'A' | 'B' | label
  impressions integer not null default 0,
  conversions integer not null default 0,
  status      text not null default 'live',  -- live | done
  created_at  timestamptz not null default now()
);
alter table experiments enable row level security;
create policy "admins read experiments"  on experiments for select using (has_role(auth.uid(),'admin'));
create policy "admins write experiments" on experiments for all    using (has_role(auth.uid(),'admin')) with check (has_role(auth.uid(),'admin'));

-- 1 · KPI headline
create or replace view admin_kpis as
select
  count(*) filter (where o.status in ('sent','redeemed'))                    as gifts_sent,
  count(distinct o.sender_id) filter (where o.status in ('sent','redeemed')) as active_senders,
  round(100.0 * count(*) filter (where o.status='redeemed')
        / nullif(count(*) filter (where o.status in ('sent','redeemed')),0),0) as redemption_rate,
  count(*) filter (where o.referred_from_order_id is not null)               as gift_backs,
  coalesce(sum(g.value_cents) filter (where o.status='redeemed'
        and date_trunc('month',o.sent_at)=date_trunc('month',now())),0)/100.0 as revenue_mtd_eur,
  round(avg(g.value_cents)/100.0,2)                                          as avg_gift_cost_eur
from orders o join gifts g on g.id=o.gift_id;

-- 2 · Monthly trend (last 12 months)
create or replace view admin_gifts_by_month as
select date_trunc('month', sent_at) as month, count(*) as sent
from orders where status in ('sent','redeemed') and sent_at > now()-interval '12 months'
group by 1 order by 1;

-- 3 · Mix by tier
create or replace view admin_tier_mix as
select g.tier, count(*) as sent,
       round(100.0*count(*)/sum(count(*)) over (),0) as pct
from orders o join gifts g on g.id=o.gift_id
where o.status in ('sent','redeemed') group by g.tier;

-- 4 · Occasions
create or replace view admin_occasions as
select coalesce(occasion,'other') as occasion, count(*) as sent,
       round(100.0*count(*)/sum(count(*)) over (),0) as pct
from orders where status in ('sent','redeemed') group by 1 order by 2 desc;

-- 5 · Funnel
create or replace view admin_funnel as
select
  count(*) filter (where status in ('sent','redeemed'))       as sent,
  count(*) filter (where status='redeemed')                   as redeemed,
  count(*) filter (where referred_from_order_id is not null)  as gifted_back
from orders;

-- 6 · Catalog performance (per gift)
create or replace view admin_gift_performance as
select g.title, g.category, g.tier,
       count(o.*) filter (where o.status in ('sent','redeemed')) as sent,
       round(100.0*count(o.*) filter (where o.status='redeemed')
             / nullif(count(o.*) filter (where o.status in ('sent','redeemed')),0),0) as redeem_pct,
       coalesce(sum(g.value_cents) filter (where o.status='redeemed'),0)/100.0 as revenue_eur
from gifts g left join orders o on o.gift_id=g.id
group by g.id, g.title, g.category, g.tier order by sent desc nulls last;

-- 7 · Category rollup
create or replace view admin_category_rollup as
select g.category, g.tier, count(o.*) as sent,
       round(100.0*count(o.*)/sum(count(o.*)) over (),0) as pct
from gifts g join orders o on o.gift_id=g.id
where o.status in ('sent','redeemed') group by g.category, g.tier order by sent desc;

-- 8 · Geography
create or replace view admin_by_country as
select recipient_country as country, count(*) as sent,
       round(100.0*count(*)/sum(count(*)) over (),0) as pct
from orders where status in ('sent','redeemed') and recipient_country is not null
group by 1 order by 2 desc;

-- 9 · Sender segments
create or replace view admin_segments as
select coalesce(p.persona,'other') as persona, count(o.*) as sent,
       round(100.0*count(o.*)/sum(count(o.*)) over (),0) as pct
from orders o join profiles p on p.id=o.sender_id
where o.status in ('sent','redeemed') group by 1 order by 2 desc;

-- 10 · Message + delivery stats
create or replace view admin_message_stats as
select round(avg(length(message)),0) as avg_len,
       round(100.0*count(*) filter (where message ~ '[A-Z][a-z]+')/nullif(count(*),0),0) as pct_named,
       round(100.0*count(*) filter (where delivery_mode='link')/nullif(count(*),0),0)   as pct_link
from orders where status in ('sent','redeemed') and message is not null;

-- 11 · Send-by-hour
create or replace view admin_send_by_hour as
select extract(hour from sent_at)::int as hour, count(*) as sent
from orders where status in ('sent','redeemed') group by 1 order by 1;

-- 12 · Channels (needs orders.channel; defaults to organic)
create or replace view admin_channels as
select coalesce(channel,'organic') as channel,
       count(distinct sender_id) as signups,
       count(distinct sender_id) filter (where status in ('sent','redeemed')) as activated
from orders group by 1 order by 2 desc;

-- 13 · A/B results
create or replace view admin_experiments as
select name, metric, variant, impressions, conversions, status,
       round(100.0*conversions/nullif(impressions,0),1) as rate_pct
from experiments order by name, variant;
