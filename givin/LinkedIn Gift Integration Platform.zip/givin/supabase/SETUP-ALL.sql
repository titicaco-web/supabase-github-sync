-- ═══════════════════════════════════════════════════════════════
-- GIVIN — COMPLETE DATABASE SETUP (all migrations, in order)
-- ═══════════════════════════════════════════════════════════════
-- HOW TO USE:
--   1. Supabase.com → your project → SQL Editor → New query
--   2. Copy EVERYTHING in this file, paste, click RUN.
--   3. Then make yourself admin (replace the id with YOUR auth user id,
--      found in Authentication → Users):
--        insert into user_roles (user_id, role)
--        values ('YOUR-USER-ID','admin')
--        on conflict do nothing;
--
-- Safe to re-run: everything uses "if not exists" / "on conflict do nothing"
-- / "create or replace". Running twice will not duplicate or break data.
-- ═══════════════════════════════════════════════════════════════


-- ╔══════════════════════════════════════════════════════════════╗
-- ║  0001_init.sql                                             ║
-- ╚══════════════════════════════════════════════════════════════╝

-- ─────────────────────────────────────────────────────────────
-- Givin · initial schema, RLS, and seed catalog
-- ─────────────────────────────────────────────────────────────
-- Run with: supabase db reset   (applies this + seeds below)

create extension if not exists pgcrypto;

-- Roles kept in their OWN table (never on the profile) to prevent
-- privilege escalation.
do $$ begin
  create type app_role as enum ('user', 'admin');
exception when duplicate_object then null; end $$;

-- ── profiles ────────────────────────────────────────────────
-- One row per authenticated user, mirrored from auth.users.
create table if not exists profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text,
  email       text,
  photo_url   text,
  created_at  timestamptz not null default now()
);

create table if not exists user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role    app_role not null default 'user',
  primary key (user_id, role)
);

-- ── gift catalog ────────────────────────────────────────────
create table if not exists gifts (
  id         uuid primary key default gen_random_uuid(),
  slug       text unique not null,
  title      text not null,
  category   text not null,                 -- flowers | coffee | chocolate | giftcard
  tier       text not null default 'paid',  -- free | paid
  value_cents integer not null default 0,   -- face value charged to sender (0 = free)
  currency   text not null default 'EUR',
  image_url  text,
  active     boolean not null default true,
  created_at timestamptz not null default now()
);

-- ── saved recipients (the sender's address book) ────────────
create table if not exists recipients (
  id         uuid primary key default gen_random_uuid(),
  owner_id   uuid not null references auth.users(id) on delete cascade,
  name       text not null,
  email      text,
  headline   text,
  note       text,
  key_dates  jsonb not null default '[]',   -- [{label, date}]
  created_at timestamptz not null default now()
);

-- ── orders (a gift being sent) ──────────────────────────────
create table if not exists orders (
  id            uuid primary key default gen_random_uuid(),
  public_token  uuid not null default gen_random_uuid(),  -- used by the redeem page
  sender_id     uuid not null references auth.users(id) on delete cascade,
  gift_id       uuid not null references gifts(id),
  recipient_name  text not null,
  recipient_email text not null,
  occasion      text,                       -- new_job | work_anniversary | great_call | ...
  message       text,
  status        text not null default 'draft', -- draft|scheduled|sent|redeemed|failed
  send_at       timestamptz,
  sent_at       timestamptz,
  redeemed_at   timestamptz,
  tremendous_id text,
  reward_link   text,                        -- revealed on redeem
  stripe_id     text,
  referred_from_order_id uuid references orders(id),
  created_at    timestamptz not null default now()
);
create index if not exists orders_sender_idx on orders(sender_id);
create index if not exists orders_token_idx  on orders(public_token);

-- ── credits (free-gift allowance per user/period) ───────────
create table if not exists credits (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users(id) on delete cascade,
  free_remaining integer not null default 3,
  period         text not null default to_char(now(), 'YYYY-MM'),
  source         text not null default 'signup', -- signup | sponsor
  unique (user_id, period)
);

-- ── security definer role check ─────────────────────────────
create or replace function has_role(_user_id uuid, _role app_role)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from user_roles where user_id = _user_id and role = _role
  );
$$;

-- ── new-user trigger: create profile + role + credits ───────
create or replace function handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into profiles (id, name, email, photo_url)
    values (new.id,
            new.raw_user_meta_data->>'name',
            new.email,
            new.raw_user_meta_data->>'picture')
    on conflict (id) do nothing;
  insert into user_roles (user_id, role) values (new.id, 'user')
    on conflict do nothing;
  insert into credits (user_id) values (new.id)
    on conflict do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ─────────────────────────────────────────────────────────────
-- Row-Level Security: a user sees only their own data.
-- Redeem/send go through edge functions (service role), so the
-- public never reads the orders table directly.
-- ─────────────────────────────────────────────────────────────
alter table profiles   enable row level security;
alter table user_roles enable row level security;
alter table recipients enable row level security;
alter table orders     enable row level security;
alter table credits    enable row level security;
alter table gifts      enable row level security;

create policy "own profile"        on profiles   for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "own roles read"     on user_roles for select using (auth.uid() = user_id);
create policy "own recipients"     on recipients for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "own orders"         on orders     for all using (auth.uid() = sender_id) with check (auth.uid() = sender_id);
create policy "own credits"        on credits    for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "anyone reads active gifts" on gifts for select using (active = true);
create policy "admins manage gifts" on gifts for all using (has_role(auth.uid(), 'admin')) with check (has_role(auth.uid(), 'admin'));

-- ── seed catalog ────────────────────────────────────────────
insert into gifts (slug, title, category, tier, value_cents, currency) values
  ('seasonal-bouquet', 'Seasonal bouquet', 'flowers',  'free',    0, 'EUR'),
  ('coffee-voucher',   'Coffee voucher',   'coffee',   'free',    0, 'EUR'),
  ('chocolate-box',    'Chocolate box',    'chocolate','paid',  900, 'EUR'),
  ('gift-card-10',     'Gift card €10',    'giftcard', 'paid', 1000, 'EUR'),
  ('gift-card-25',     'Gift card €25',    'giftcard', 'paid', 2500, 'EUR'),
  ('gift-card-50',     'Gift card €50',    'giftcard', 'paid', 5000, 'EUR')
on conflict (slug) do nothing;


-- ╔══════════════════════════════════════════════════════════════╗
-- ║  0002_catalog.sql                                          ║
-- ╚══════════════════════════════════════════════════════════════╝

-- ─────────────────────────────────────────────────────────────
-- Givin · catalog v1
-- Adds catalog metadata and seeds three tiers of gifts:
--   tier 'free'  + gift_type 'digital'  → public domain, €0, no provider, no legal risk
--   tier 'trial' + gift_type 'trial'    → affiliate / revenue-share trial, €0 to us
--   tier 'paid'  + gift_type 'physical' → real-world reward via Tremendous
-- ─────────────────────────────────────────────────────────────

alter table gifts add column if not exists gift_type     text not null default 'physical'; -- digital | trial | physical
alter table gifts add column if not exists source_url    text;     -- digital: content URL · trial: affiliate URL
alter table gifts add column if not exists provider      text;     -- brand behind a trial
alter table gifts add column if not exists revenue_share boolean not null default false;
alter table gifts add column if not exists trial_days    integer;  -- nominal trial length (confirm live per provider)
alter table gifts add column if not exists notes         text;

-- Reclassify the original seed: flowers/coffee are real-world costs, not "free".
update gifts set gift_type = 'physical', tier = 'paid', value_cents = 1900 where slug = 'seasonal-bouquet';
update gifts set gift_type = 'physical', tier = 'paid', value_cents = 500  where slug = 'coffee-voucher';
update gifts set gift_type = 'physical' where slug in ('chocolate-box','gift-card-10','gift-card-25','gift-card-50');

-- ── FREE · public domain / open-licensed (gift_type = digital) ──
insert into gifts (slug, title, category, tier, gift_type, value_cents, currency, source_url, notes) values
  ('pg-ebook',        'A classic e-book',            'ebook',     'free', 'digital', 0, 'EUR', 'https://www.gutenberg.org',                 'Project Gutenberg — 70k+ public-domain titles'),
  ('standard-ebooks', 'A beautifully-set e-book',    'ebook',     'free', 'digital', 0, 'EUR', 'https://standardebooks.org',                'Standard Ebooks — carefully formatted classics'),
  ('open-library',    'Borrow any book',             'ebook',     'free', 'digital', 0, 'EUR', 'https://openlibrary.org',                   'Open Library / Internet Archive'),
  ('manybooks',       'Pick from ManyBooks',         'ebook',     'free', 'digital', 0, 'EUR', 'https://manybooks.net',                     'Free fiction & non-fiction'),
  ('wikibooks',       'An open textbook',            'ebook',     'free', 'digital', 0, 'EUR', 'https://www.wikibooks.org',                 'Open-content textbooks'),
  ('bookboon',        'A free business textbook',    'ebook',     'free', 'digital', 0, 'EUR', 'https://bookboon.com',                      'Business & study e-books (ad-supported)'),
  ('librivox',        'A free audiobook',            'audiobook', 'free', 'digital', 0, 'EUR', 'https://librivox.org',                      'LibriVox — volunteer-read public domain'),
  ('archive-audio',   'Archive audiobook',           'audiobook', 'free', 'digital', 0, 'EUR', 'https://archive.org/details/audio',         'Internet Archive audio'),
  ('lit2go',          'Lit2Go audiobook',            'audiobook', 'free', 'digital', 0, 'EUR', 'https://etc.usf.edu/lit2go/',               'Stories & poems, free'),
  ('musopen',         'Classical music',             'music',     'free', 'digital', 0, 'EUR', 'https://musopen.org',                       'Royalty-free classical recordings'),
  ('free-music-arch', 'A music playlist',            'music',     'free', 'digital', 0, 'EUR', 'https://freemusicarchive.org',              'Free Music Archive — CC-licensed'),
  ('jamendo',         'Indie music',                 'music',     'free', 'digital', 0, 'EUR', 'https://www.jamendo.com',                   'Free music with license'),
  ('ccmixter',        'Remixable music',             'music',     'free', 'digital', 0, 'EUR', 'http://ccmixter.org',                       'CC remix community'),
  ('archive-films',   'A classic film',              'film',      'free', 'digital', 0, 'EUR', 'https://archive.org/details/feature_films', 'Public-domain feature films'),
  ('openculture-film','Curated free movies',         'film',      'free', 'digital', 0, 'EUR', 'https://www.openculture.com/freemoviesonline', 'Open Culture movie list'),
  ('khan-academy',    'A learning track',            'learning',  'free', 'digital', 0, 'EUR', 'https://www.khanacademy.org',               'Khan Academy'),
  ('mit-ocw',         'A university course',         'learning',  'free', 'digital', 0, 'EUR', 'https://ocw.mit.edu',                       'MIT OpenCourseWare'),
  ('freecodecamp',    'Learn to code',               'learning',  'free', 'digital', 0, 'EUR', 'https://www.freecodecamp.org',              'freeCodeCamp')
on conflict (slug) do nothing;

-- ── TRIAL · affiliate / revenue-share (gift_type = trial) ──────
-- value_cents = 0 (the sender pays nothing); we may earn on conversion.
-- VERIFY each program's terms — some restrict incentivized/gifted signups —
-- and confirm the current trial length before relying on trial_days.
insert into gifts (slug, title, category, tier, gift_type, value_cents, currency, source_url, provider, revenue_share, trial_days, notes) values
  ('audible-trial',   'Audible trial',               'audiobook', 'trial', 'trial', 0, 'EUR', 'https://www.audible.com',           'Audible',          true, 30, 'Audiobook trial · cancel-reminder on'),
  ('blinkist-trial',  'Blinkist trial',              'audiobook', 'trial', 'trial', 0, 'EUR', 'https://www.blinkist.com',          'Blinkist',         true, 7,  'Book summaries — great for pros'),
  ('shortform-trial', 'Shortform trial',             'audiobook', 'trial', 'trial', 0, 'EUR', 'https://www.shortform.com',         'Shortform',        true, 5,  'In-depth book guides'),
  ('everand-trial',   'Everand trial',               'audiobook', 'trial', 'trial', 0, 'EUR', 'https://www.everand.com',           'Everand (Scribd)', true, 30, 'Books + audiobooks'),
  ('spotify-trial',   'Spotify Premium trial',       'music',     'trial', 'trial', 0, 'EUR', 'https://www.spotify.com/premium',   'Spotify',          true, 30, 'Music · cancel-reminder on'),
  ('apple-music-trial','Apple Music trial',          'music',     'trial', 'trial', 0, 'EUR', 'https://music.apple.com',           'Apple Music',      true, 30, 'Music trial'),
  ('youtube-premium', 'YouTube Premium trial',       'music',     'trial', 'trial', 0, 'EUR', 'https://www.youtube.com/premium',   'YouTube',          true, 30, 'Music + ad-free video'),
  ('linkedin-learning','LinkedIn Learning trial',    'learning',  'trial', 'trial', 0, 'EUR', 'https://www.linkedin.com/learning', 'LinkedIn Learning',true, 30, 'Professional courses'),
  ('skillshare-trial','Skillshare trial',            'learning',  'trial', 'trial', 0, 'EUR', 'https://www.skillshare.com',        'Skillshare',       true, 30, 'Creative & business classes'),
  ('coursera-plus',   'Coursera Plus trial',         'learning',  'trial', 'trial', 0, 'EUR', 'https://www.coursera.org',          'Coursera',         true, 7,  'University-grade courses'),
  ('masterclass-gift','MasterClass',                 'learning',  'trial', 'trial', 0, 'EUR', 'https://www.masterclass.com',       'MasterClass',      true, null,'Giftable membership'),
  ('headspace-trial', 'Headspace trial',             'wellbeing', 'trial', 'trial', 0, 'EUR', 'https://www.headspace.com',         'Headspace',        true, 14, 'Meditation'),
  ('calm-trial',      'Calm trial',                  'wellbeing', 'trial', 'trial', 0, 'EUR', 'https://www.calm.com',              'Calm',             true, 7,  'Sleep & focus'),
  ('nyt-trial',       'New York Times trial',        'reading',   'trial', 'trial', 0, 'EUR', 'https://www.nytimes.com',           'NYT',              true, null,'News subscription trial'),
  ('economist-trial', 'The Economist trial',         'reading',   'trial', 'trial', 0, 'EUR', 'https://www.economist.com',         'The Economist',    true, null,'Business news'),
  ('medium-trial',    'Medium membership trial',     'reading',   'trial', 'trial', 0, 'EUR', 'https://medium.com/membership',     'Medium',           true, null,'Unlimited articles'),
  ('notion-trial',    'Notion Plus trial',           'tools',     'trial', 'trial', 0, 'EUR', 'https://www.notion.so',             'Notion',           true, null,'Productivity'),
  ('canva-pro-trial', 'Canva Pro trial',             'tools',     'trial', 'trial', 0, 'EUR', 'https://www.canva.com',             'Canva',            true, 30, 'Design tool'),
  ('grammarly-trial', 'Grammarly Premium trial',     'tools',     'trial', 'trial', 0, 'EUR', 'https://www.grammarly.com',         'Grammarly',        true, 7,  'Writing assistant')
on conflict (slug) do nothing;


-- ╔══════════════════════════════════════════════════════════════╗
-- ║  0003_link_delivery.sql                                    ║
-- ╚══════════════════════════════════════════════════════════════╝

-- ─────────────────────────────────────────────────────────────
-- Givin · shareable gift links
-- A sender can create a gift LINK (no recipient email needed) and
-- paste it into a LinkedIn message or post. So email becomes optional
-- and we record how the gift was delivered.
-- ─────────────────────────────────────────────────────────────

alter table orders alter column recipient_email drop not null;
alter table orders alter column recipient_name set default 'A friend';
alter table orders add column if not exists delivery_mode text not null default 'email'; -- link | email


-- ╔══════════════════════════════════════════════════════════════╗
-- ║  0004_analytics.sql                                        ║
-- ╚══════════════════════════════════════════════════════════════╝

-- ─────────────────────────────────────────────────────────────
-- Givin · analytics — admin dashboard views + supporting columns
-- Powers "Givin Admin Dashboard". All figures derive from
-- orders / gifts / recipients / profiles. Admin-only access is
-- enforced in the app via has_role(auth.uid(),'admin').
-- ─────────────────────────────────────────────────────────────

-- Optional columns that enable the geography / segment / channel cuts.
alter table orders   add column if not exists recipient_country text; -- ISO-2, set at redeem
alter table orders   add column if not exists channel text;           -- utm source at first touch
alter table profiles add column if not exists persona text;           -- sales|recruiter|founder|consultant

-- gifts.revenue not stored per-order; we approximate paid revenue from value_cents.

-- ── A/B experiments (written by the app; empty until used) ──
create table if not exists experiments (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  metric      text,
  variant     text not null,          -- 'A' | 'B' | label
  impressions integer not null default 0,
  conversions integer not null default 0,
  status      text not null default 'live',  -- live | done
  created_at  timestamptz not null default now()
);
alter table experiments enable row level security;
create policy "admins read experiments"  on experiments for select using (has_role(auth.uid(),'admin'));
create policy "admins write experiments" on experiments for all    using (has_role(auth.uid(),'admin')) with check (has_role(auth.uid(),'admin'));

-- 1 · KPI headline
create or replace view admin_kpis as
select
  count(*) filter (where o.status in ('sent','redeemed'))                    as gifts_sent,
  count(distinct o.sender_id) filter (where o.status in ('sent','redeemed')) as active_senders,
  round(100.0 * count(*) filter (where o.status='redeemed')
        / nullif(count(*) filter (where o.status in ('sent','redeemed')),0),0) as redemption_rate,
  count(*) filter (where o.referred_from_order_id is not null)               as gift_backs,
  coalesce(sum(g.value_cents) filter (where o.status='redeemed'
        and date_trunc('month',o.sent_at)=date_trunc('month',now())),0)/100.0 as revenue_mtd_eur,
  round(avg(g.value_cents)/100.0,2)                                          as avg_gift_cost_eur
from orders o join gifts g on g.id=o.gift_id;

-- 2 · Monthly trend (last 12 months)
create or replace view admin_gifts_by_month as
select date_trunc('month', sent_at) as month, count(*) as sent
from orders where status in ('sent','redeemed') and sent_at > now()-interval '12 months'
group by 1 order by 1;

-- 3 · Mix by tier
create or replace view admin_tier_mix as
select g.tier, count(*) as sent,
       round(100.0*count(*)/sum(count(*)) over (),0) as pct
from orders o join gifts g on g.id=o.gift_id
where o.status in ('sent','redeemed') group by g.tier;

-- 4 · Occasions
create or replace view admin_occasions as
select coalesce(occasion,'other') as occasion, count(*) as sent,
       round(100.0*count(*)/sum(count(*)) over (),0) as pct
from orders where status in ('sent','redeemed') group by 1 order by 2 desc;

-- 5 · Funnel
create or replace view admin_funnel as
select
  count(*) filter (where status in ('sent','redeemed'))       as sent,
  count(*) filter (where status='redeemed')                   as redeemed,
  count(*) filter (where referred_from_order_id is not null)  as gifted_back
from orders;

-- 6 · Catalog performance (per gift)
create or replace view admin_gift_performance as
select g.title, g.category, g.tier,
       count(o.*) filter (where o.status in ('sent','redeemed')) as sent,
       round(100.0*count(o.*) filter (where o.status='redeemed')
             / nullif(count(o.*) filter (where o.status in ('sent','redeemed')),0),0) as redeem_pct,
       coalesce(sum(g.value_cents) filter (where o.status='redeemed'),0)/100.0 as revenue_eur
from gifts g left join orders o on o.gift_id=g.id
group by g.id, g.title, g.category, g.tier order by sent desc nulls last;

-- 7 · Category rollup
create or replace view admin_category_rollup as
select g.category, g.tier, count(o.*) as sent,
       round(100.0*count(o.*)/sum(count(o.*)) over (),0) as pct
from gifts g join orders o on o.gift_id=g.id
where o.status in ('sent','redeemed') group by g.category, g.tier order by sent desc;

-- 8 · Geography
create or replace view admin_by_country as
select recipient_country as country, count(*) as sent,
       round(100.0*count(*)/sum(count(*)) over (),0) as pct
from orders where status in ('sent','redeemed') and recipient_country is not null
group by 1 order by 2 desc;

-- 9 · Sender segments
create or replace view admin_segments as
select coalesce(p.persona,'other') as persona, count(o.*) as sent,
       round(100.0*count(o.*)/sum(count(o.*)) over (),0) as pct
from orders o join profiles p on p.id=o.sender_id
where o.status in ('sent','redeemed') group by 1 order by 2 desc;

-- 10 · Message + delivery stats
create or replace view admin_message_stats as
select round(avg(length(message)),0) as avg_len,
       round(100.0*count(*) filter (where message ~ '[A-Z][a-z]+')/nullif(count(*),0),0) as pct_named,
       round(100.0*count(*) filter (where delivery_mode='link')/nullif(count(*),0),0)   as pct_link
from orders where status in ('sent','redeemed') and message is not null;

-- 11 · Send-by-hour
create or replace view admin_send_by_hour as
select extract(hour from sent_at)::int as hour, count(*) as sent
from orders where status in ('sent','redeemed') group by 1 order by 1;

-- 12 · Channels (needs orders.channel; defaults to organic)
create or replace view admin_channels as
select coalesce(channel,'organic') as channel,
       count(distinct sender_id) as signups,
       count(distinct sender_id) filter (where status in ('sent','redeemed')) as activated
from orders group by 1 order by 2 desc;

-- 13 · A/B results
create or replace view admin_experiments as
select name, metric, variant, impressions, conversions, status,
       round(100.0*conversions/nullif(impressions,0),1) as rate_pct
from experiments order by name, variant;


